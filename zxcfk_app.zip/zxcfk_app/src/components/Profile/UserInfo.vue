<template>
    <v-app>
      <v-main>
        UserInfo
      </v-main>
    </v-app>
  </template>
  
  <script>
  
  export default {
    name: 'UserInfo',
  
    components: {
    },
  
    data: () => ({
      //
    }),
  }
  </script>
  