<template>
    <v-app>
      <v-main>
        Main
      </v-main>
    </v-app>
  </template>
  
  <script>
  
  export default {
    name: 'Main',
  
    components: {
    },
  
    data: () => ({
      //
    }),
  }
  </script>
  